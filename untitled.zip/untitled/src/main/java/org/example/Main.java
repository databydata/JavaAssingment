package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("**********Welcome to calculator**********");
        Scanner sc = new Scanner(System.in);
        int choice;

        int attempt = 5;

        do {
            System.out.println("Enter your choice");
            System.out.println("Press 1 for sum");
            System.out.println("Press 2 for difference");
            System.out.println("Press 3 for product");
            System.out.println("Press 4 for division");
            System.out.println("Press 5 for EXIT");
            choice = sc.nextInt();
            switch (choice)
            {
                case 1:
                    System.out.println("Enter 1st number");
                    int Input1 = sc.nextInt();
                    System.out.println("Enter 2nd number");
                    int Input2 = sc.nextInt();
                    int sum = Input1 + Input2;
                    System.out.println("The Sum of two numbers: "+ sum);
                    break;

                case 2:
                    System.out.println("Enter 1st number");
                    int sub1 = sc.nextInt();
                    System.out.println("Enter 2nd number");
                    int sub2 = sc.nextInt();
                    int diff = sub1 - sub2;
                    System.out.println("The difference of two numbers: "+ diff);
                    break;

                case 3:
                    System.out.println("Enter 1st number");
                    int mul1 = sc.nextInt();
                    System.out.println("Enter 2nd number");
                    int mul2 = sc.nextInt();
                    int prod = sc.nextInt();
                    System.out.println("The product of two numbers: " + prod);
                    break;

                case 4:
                    System.out.println("Enter 1st number");
                    int div1 = sc.nextInt();
                    System.out.println("Enter 2nd number");
                    int div2 = sc.nextInt();
                    int div;
                    if(div2 != 0)
                    {
                        div = div1/div2;
                    }else {
                        System.out.println("Cant be divided by zero!");
                        break;
                    }
                    System.out.println("The division of two numbers: " + div);
                    break;

                case 5:
                    System.exit(0);
                    break;

                default:
                    System.out.println("==============");
                    System.out.println("Invalid input");
                    System.out.println("==============");
                    attempt--;
                    if(attempt > 0)
                    {
                        System.out.println("You have "+attempt+" tries left, Please enter correct choice!!!");
                        System.out.println("\n");
                    }

            }

        }while(choice !=0 && attempt != 0);

    }
}
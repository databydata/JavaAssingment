package exceptions;

public class ZeroBalException extends Exception {
	
	@Override
	public String toString()
	{
		return "Sorry, You cannot make your account balance zero!";
	}
	
}

//Part 2

package account_JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import exceptions.InsufficientBalException;
import exceptions.ZeroBalException;

public class AccountDAO {
	Connection con;
	Statement st;
	PreparedStatement pst;
	
	public AccountDAO() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void create(Account a) throws SQLException {
		
		//Connection
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/account", "root", "123456");
		st = con.createStatement();
		
		//Query
		String s = "insert into account_details values (?, ?, ?);";
		pst = con.prepareStatement(s);
		pst.setLong(1, a.getId());
		pst.setString(2, a.getName());
		pst.setDouble(3, a.getBalance());
		pst.executeUpdate();
	}

	public void update(Long id, double balance) throws SQLException{
		
		System.out.println("In Update:"+id+":"+":"+balance);
		
		//Connection
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/account", "root", "123456");
		st = con.createStatement();
		
		//Query
		String s = "update account_details set balance = ? where id = ?;";
		pst = con.prepareStatement(s);
		pst.setDouble(1, balance);
		pst.setLong(2, id);
		pst.executeUpdate();
	}


	public void withdraw(Long id, double balance, double dedAmount) throws SQLException, InsufficientBalException, ZeroBalException {
		
		System.out.println("In withdraw:- "+id+":"+dedAmount+":"+balance);
		
		if (dedAmount < balance) {
			double rest = balance-dedAmount;
			this.update(id, rest);
		}
		else if(dedAmount == balance){
			throw new ZeroBalException();
		}
		
		else  {
			throw new InsufficientBalException();
		}
	}

}

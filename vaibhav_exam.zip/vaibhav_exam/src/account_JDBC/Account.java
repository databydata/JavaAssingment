package account_JDBC;

import exceptions.InsufficientBalException;

public class Account{
	
	private Long id;
	private double balance;
	private String name;
	
	
	
	public Account(Long id,String name, double balance) {
		super();
		this.id = id;
		this.name = name;
		this.balance = balance;
	}
	
	

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public Long getId() {
		return id;
	}




	public void setId(Long id) {
		this.id = id;
	}




	public double getBalance() {
		return balance;
	}




	public void setBalance(double balance) throws Exception{
		
		if(this.balance > 0)
			this.balance = balance;
		
	}



	@Override
	public String toString() {
		return "Account [id=" + id + ", balance=" + balance + ", name=" + name + "]";
	}
	
	
}

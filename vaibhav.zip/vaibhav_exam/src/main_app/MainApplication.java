package main_app;

import java.sql.SQLException;
import java.util.Scanner;

import account_JDBC.Account;
import account_JDBC.AccountDAO;
import exceptions.InsufficientBalException;
import exceptions.ZeroBalException;

public class MainApplication {
	public static void main(String[] args) throws SQLException, InsufficientBalException, ZeroBalException {

		String yn = "no";

		// Dao
		AccountDAO dao = new AccountDAO();

		Scanner sc = new Scanner(System.in);

		System.out.println("enter account details");
		System.out.println("account id=");

		Long id = sc.nextLong();

		System.out.println("account balance=");

		double balance = sc.nextDouble();

		Account ob = new Account(id, balance);

		dao.create(ob);

		System.out.println("Account Created:-");
		System.out.println(ob);

		do {
			System.out.println("Enter Withdraw Amount =" + id);
			double dedAmount = sc.nextDouble();

			try {
				dao.withdraw(id,balance,dedAmount);
			} catch (InsufficientBalException ex) {
				System.out.println(ex);
				break;
			}

			System.out.println("do you wish to withdraw more:(yes/no):");

			yn = sc.next();

		} while (yn.equals("yes"));

	}

}

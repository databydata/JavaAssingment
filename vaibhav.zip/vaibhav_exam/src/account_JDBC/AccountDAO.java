//Part 2

package account_JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import exceptions.InsufficientBalException;
import exceptions.ZeroBalException;

public class AccountDAO {

	List<Account> accountList = new ArrayList<Account>();
	Connection con;
	Statement st;
	PreparedStatement psmt;

	
	
	public AccountDAO() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void create(Account a) throws SQLException {
		
		//Connection
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/account", "root", "123456");
		st = con.createStatement();
		
		//Query
		String s = "insert into account_details values (?, ?);";
		psmt = con.prepareStatement(s);
		psmt.setLong(1, a.getId());
		psmt.setDouble(2, a.getBalance());
		psmt.executeUpdate();
		accountList.add(a);
	}

	public void update(Long id, double balance) throws SQLException {
		
		//System.out.print("In withdraw:"+id+":"+":"+balance);
		
		//Connection
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/account", "root", "123456");
		st = con.createStatement();
		
		//Query
		String s = "update account_details set balance = ? where id = ?;";
		psmt = con.prepareStatement(s);
		psmt.setLong(1, id);
		psmt.setDouble(2, balance);
		psmt.executeUpdate();
	}


	public void withdraw(Long id, double balance, double dedAmount) throws SQLException, InsufficientBalException, ZeroBalException {
		
		System.out.print("In withdraw:"+id+":"+dedAmount+":"+balance);
		
		if (dedAmount < balance) {
			this.update(id, (balance-dedAmount));
		}
		else if(dedAmount == balance){
			throw new ZeroBalException();
		}
		
		else  {
			throw new InsufficientBalException();
		}
	}

}
